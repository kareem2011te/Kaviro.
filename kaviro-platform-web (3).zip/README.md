# KAVIRO — AI-Powered Team Management Platform

## Local Development
1. Install dependencies:
   npm install

2. Configure environment variables:
   cp .env.example .env
   Set GEMINI_API_KEY in .env for server-side Gemini AI CV analysis & KAVIRO AI Assistant.

3. Start development server (Express + WebSockets + Vite on port 3000):
   npm run dev

## Deploying to the Internet (Render / Railway / Cloud Run / VPS)
- Build Command: npm install && npm run build
- Start Command: npm start
- Required Env Vars:
  - GEMINI_API_KEY=<your_gemini_api_key>
  - KAVIRO_SESSION_SECRET=<random_long_secret>
  - KAVIRO_DATA_DIR=/var/data (optional persistent disk path)
- Or deploy directly via the included Dockerfile.
